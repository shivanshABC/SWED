package Übung4.java;

public class Main {
    public static void main(String[] args) {
        UserController controller = new UserController();

        User alice = controller.registerUser("Alice", "1234567890", "alice@example.com");
        controller.managesubscription(alice, "https://example.com", Commchannel.EMAIL, 5);

        MonitorWebsite monitor = new MonitorWebsite(5);
        for (Subscription sub : alice.getSubscriptions()) {
            monitor.addSubscription(sub);
        }

        monitor.checkforUpdate(); // May trigger a notification
    }
}


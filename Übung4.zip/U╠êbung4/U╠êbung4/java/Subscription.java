package Übung4.java;
public class Subscription {
    private String registrationID;
    private Commchannel communication;
    public int frequency;
    public String url;
    private boolean active;

    public Subscription(String registrationID, Commchannel communication, int frequency, String url) {
        this.registrationID = registrationID;
        this.communication = communication;
        this.frequency = frequency;
        this.url = url;
        this.active = true;
    }

    public void updateSubscription(int newFrequency, Commchannel newChannel) {
        this.frequency = newFrequency;
        this.communication = newChannel;
    }

    public void cancelSubscription() {
        this.active = false;
    }

    public boolean isActive() {
        return active;
    }

    public Commchannel getCommunication() {
        return communication;
    }

    public String getUrl() {
        return url;
    }

    public String getRegistrationID() {
        return registrationID;
    }
}


package Übung4.java;
    public enum Commchannel {
    EMAIL, SMS
}


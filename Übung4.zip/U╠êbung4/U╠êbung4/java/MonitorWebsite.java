package Übung4.java;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MonitorWebsite {
    public int checkInterval;
    private List<Subscription> subscriptions;

    public MonitorWebsite(int checkInterval) {
        this.checkInterval = checkInterval;
        this.subscriptions = new ArrayList<>();
    }

    public void addSubscription(Subscription subscription) {
        subscriptions.add(subscription);
    }

    public void checkforUpdate() {
        boolean updated = rectifyupdate();
        System.out.println("Update detected: " + updated);
        if (updated) {
            for (Subscription sub : subscriptions) {
                if (sub.isActive()) {
                    Notification n = new Notification(UUID.randomUUID().toString(), "Website updated: " + sub.getUrl());
                    // In a real system, you'd get the user. Simulating with a dummy contact:
                    n.sendNotification("Shivansh5000@gmail.com", sub.getCommunication());
                }
            }
        }
    }

    public boolean rectifyupdate() {
        // Dummy logic: Randomly decide update happened
        return true;
    }
}

